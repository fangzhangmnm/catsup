// 职责（单一）：弹框锚定定位——所有「跟着按钮 / 顶栏跑」的 popup 的**唯一**定位入口。
// 统一处理：position:fixed + 让到顶栏条以下 + 读 env(safe-area-inset-top)（iPad 日期/状态栏）
//   + 夹进视口（不溢出顶 / 底）。CSS 只管外观，坐标只此一处算 → 杜绝「各 popup 各写一套、漏
//   safe-area / 漏夹视口」那类 iPad 打架 bug（v267 前 fx 选单 top:70、参考窗左上角都栽过同一根因）。
//
// 不含：
//   · lasso 那批「钉死在工具栏正下方居中」的纯 CSS popup —— 位置不随按钮跑，留 CSS 零 JS、零抖动；
//   · modal sheets（sheets.ts，居中 / 底部弹层是另一套系统）。
//
// v270 收敛：原来这里有 3 个近似函数（openAnchoredPopup/anchorPopupToBtn/anchorPopupBelowToolbars，
//   feature 各缺一块）+ settings-menu / filters-adjust 各手搓一份。全部收成 positionPopup 一个核心；
//   旧名留作薄 wrapper（老调用点零改动，白捡 safe-area + 夹视口）。

// env(safe-area-inset-top) 在 JS 拿不到解析后的字面值 → 一次性探针量 padding-top（旋转 / 机型变了也准）。

// 顶部固定工具栏的最大 bottom：2026-09-02 C4 起问登记表（ui/context-toolbar），不再手填 id 数组
//   （原 _TOP_TOOLBAR_IDS 六条只登记三条，shape/picker/persp 漏——新增一条要记得改数组 = 下一次 T2）。
import { floors, safeAreaTop } from "./host-floors.ts";   // safeAreaTop 实现挪到 host-floors（A5 包化：切掉循环 import）；这里再导出保 pinned 签名
export { safeAreaTop };
// 包化（2026-09-09 A5）：「顶栏下缘」不再 import 宿主的 context-toolbar，改为 mount 时注入的 getter（configureFloors）。
export function topToolbarBottom(): number { return floors.toolbarBottom(); }

interface PositionOpts {
  anchor?: HTMLElement | null;  // 锚按钮（量其 bottom/left/right）；null = 不锚按钮，钉视口边
  align?: "left" | "right"; // 右对齐到 anchor.right / 视口右（默认 right）；左同理
  offsetY?: number;        // 锚点下方间距（默认 4）
  edgeMargin?: number;     // 无 anchor 时离视口边的距离（默认 8）
  belowToolbars?: boolean; // 让到所有可见顶栏条以下（fx 选单 / 滤镜面板）
  clampViewport?: boolean; // 夹进视口底，不溢出（默认 true；popup 须已可见才量得到高）
}

// 唯一定位核心。所有按钮锚定 / 边钉的 popup 都走它。
export function positionPopup(popupEl: HTMLElement | null, opts: PositionOpts = {}) {
  if (!popupEl) return;
  const {
    anchor = null, align = "right", offsetY = 4,
    edgeMargin = 8, belowToolbars = false, clampViewport = true,
  } = opts;
  popupEl.style.position = "fixed";
  const safeTop = safeAreaTop();
  let top: number;
  // 横向：先按 align 求名义位置，再夹进视口左右缘（v0.5.15——紧凑图标菜单锚偏边缘的槽按钮时曾溢出；
  //   与纵向同一条纪律：坐标只此一处算。popup 隐藏时量不到宽 → 跳过夹，与纵向旧行为一致）。
  const w = popupEl.offsetWidth || 0;
  if (anchor) {
    const r = anchor.getBoundingClientRect();
    top = r.bottom + offsetY;
    if (align === "right") {
      let right = window.innerWidth - r.right;
      if (w) right = Math.max(edgeMargin, Math.min(right, window.innerWidth - w - edgeMargin));
      popupEl.style.right = right + "px"; popupEl.style.left = "auto";
    } else {
      let left = r.left;
      if (w) left = Math.max(edgeMargin, Math.min(left, window.innerWidth - w - edgeMargin));
      popupEl.style.left = left + "px"; popupEl.style.right = "auto";
    }
  } else {
    top = safeTop + offsetY;
    if (align === "right") { popupEl.style.right = edgeMargin + "px"; popupEl.style.left = "auto"; }
    else { popupEl.style.left = edgeMargin + "px"; popupEl.style.right = "auto"; }
  }
  if (belowToolbars) top = Math.max(top, topToolbarBottom() + offsetY);
  top = Math.max(top, safeTop + 4);                          // safe-area floor：永不钻进 iPad 顶部栏
  if (clampViewport) {
    const h = popupEl.offsetHeight || 0;                     // 已隐藏 → 0 → 跳过夹（与旧行为一致）
    if (h) top = Math.min(top, Math.max(safeTop + 4, window.innerHeight - h - 8));
  }
  popupEl.style.top = top + "px";
}

// （anchorPopupToBtn / anchorPopupBelowToolbars 兼容 wrapper 2026-09-02 C1 退役：菜单锚定全走 ui/popup-menu → positionPopup；零消费者）
