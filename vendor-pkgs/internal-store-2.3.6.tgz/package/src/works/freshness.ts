// ⚠ 使用前必读 README.md + CONTEXT.md。app 不直接 import——经 createStore。
//
// freshness（深模块）—— 进入/事件时的"云端动没动 → clean 快进 / dirty surface"。单一职责 =
//   freshness gate（ADR-0016）：比 seenBase vs 云端 etag；clean 且动过 → 静默无损快进；
//   dirty 且动过 → 交 ui 选（绝不静默覆盖 dirty）。编排 local-head.seenBase/isDirty + safe-resolve.safePull。
//   open = 开 session 的 gate（probe 可跳到离线）；refresh = 事件驱动(focus/visibility/online)的纯干净快进。
import { reportStoreError } from "../base/error-handling.ts";   // 全接但分级：静默 swallow 也 funnel（不改控制流）
import type { CloudSync, FetchMetaResult } from "../base/types.ts";
import type { LocalHead } from "./local-head.ts";
import type { SafeResolve, ResolveChoice } from "./safe-resolve.ts";
import type { FreshHints } from "./fresh-hints.ts";

import type { Busy } from "../base/types.ts";
const passBusy: Busy = (_l, fn) => fn();
import type { AdoptFn } from "../base/types.ts";

export interface FreshnessCfg {
  cloud: Pick<CloudSync, "fetchMeta">;
  head: Pick<LocalHead, "seenBase" | "isDirtyAnywhere" | "markSeen">;
  safeResolve: Pick<SafeResolve, "safePull"> & Partial<Pick<SafeResolve, "tryHeal">>;
  busy?: Busy;
  /** 0.17.0：刚列过的云端帧（fresh-hints.ts）。只在「提示 etag === 本 tab 已见 base」时省掉 fetchMeta；别的情况一律照常问云端。 */
  hints?: Pick<FreshHints, "peek">;
  /** 0.18.0（默认 true）：open 的云端核对**没跑成**（离线 / 未登录 / 云端出错 / 用户跳过）时，本地副本**干净**且磁盘上有上次同步的
   *  etag → 把那个 etag 记为本 tab 的 base。证据从「云端刚确认没动」换成「本地干净 + 上次同步到的版本」。
   *  安全边界：base 只会被记成**本地字节当时同步到的那一版**，永远不会比字节更新 → 之后第一次推 If-Match 它：云端没动 → 成功；
   *  云端动过 → 412 → tryHeal / 冲突面，和今天一样。关掉（false）= 0.17.2 的行为：登录前开稿、再打字 → 无 base → 409 → 冤枉的冲突面
   *  （WXHW 2026-10-16 单设备根因，`20260516 WebXiaoHeiWu/ai-docs/20261008-store-0162-signin-push-order-handoff.md` §6.1）。 */
  lineageFromDurable?: boolean;
}

export interface OpenOpts {
  isOnline?: () => boolean;
  probe?: Promise<unknown> | unknown;            // E8：与 metadata race，先到先得（无硬超时）
  onNewer?: (ctx: { name: string; cloudEtag: string; baseEtag: string | null; cloudTime: string | number }) => ResolveChoice | Promise<ResolveChoice>;
  adopt?: AdoptFn;
  localDirty?: () => boolean;
  busy?: Busy;
  /** 2.2.2：本地 at-rest 字节（给回执丢失自愈用）。给了 → 脏 ∧ 云端动过时，先拉云端逐字节比：一样 = 上次推其实落了、只是回执没回来 → markSynced、不弹面；
   *  不一样才交 onNewer。和 push 路径的 tryHeal 是同一条规则（MoonSinger 2026-10-08「一直会遇到云端冲突的提示」= 这条路以前只在推时有，open 时没有，
   *  所以 MoonSinger 开歌前先批量推一遍借它自愈；user 2026-10-26「批，库出 2.2.2」）。拉的过程照样被 probe（「跳过到离线」）打断：慢网不许把人卡死。 */
  localBytes?: () => Promise<Uint8Array | null>;
  /** 2.3.2（审稿补，Fable 5.2）：localBytes 交出来的那一份，到认领的那一刻还是不是盘上的那一份、有没有发出了还没落盘的保存。
   *  为假 = 不认领成已同步（网盘那一版记成基准、待传留着）。不给 = 2.3.1 行为（单元测试的替身）。createStore 一定给。 */
  localSettled?: () => boolean;
}
/** refresh（事件驱动的纯干净快进）的选项。 */
export interface RefreshOpts {
  /** 在线判定注入。 */
  isOnline?: () => boolean;
  /** 采纳验真回调。 */
  adopt?: AdoptFn;
  /** 本地 dirty 判定注入。 */
  localDirty?: () => boolean;
  /** N10：真要拉内容（动过+clean）才触发，app 给非阻塞 status。 */
  onReplaceStart?: () => void;
  /** 逃生 probe（对齐 open 的 E8，user 即超时）：与快进下载 race，probe 先到 → 返 {status:"escaped"}，
   *  本地/谱系分毫不动（换字节/markSynced 全在 safePull 尾段，逃生时还没发生）。语义（2026-08-25 拍板）：
   *  逃生 = 用户 consent **显式分叉**（换世界线不等待），app 据 "escaped" 把当前画面另存新身份；
   *  迟到完成的下载 = 原名缓存的静默刷新（无 adopt，画布不碰），无害且有益。 */
  probe?: Promise<unknown>;
  /** busy 遮罩注入。 */
  busy?: Busy;
  /** 0.18.1（默认 true）：要不要采信「刚列过的云端帧」（fresh-hints，30 s 时效）当作「云端没动」的证据。
   *  false = 这次一定问云端（fetchMeta）。用在 app **怀疑自己过期**的时刻：挂机 / 锁屏醒来、回前台、刚登录——别的设备可能就在这 30 s 里推过
   *  （WXHW e2e「挂机：别的设备改过、这台干净 → 醒来静默快进」在 0.17.0 fresh-hints 下翻红：醒来那次核对被 30 s 内的旧清单顶掉、没快进）。
   *  连着 open 几十个小文件那种场景保持默认 true。 */
  trustHints?: boolean;
}
/** open / refresh 的终态。 */
export interface FreshResult {
  /** 内容来源串。 */
  source?: string;
  /** 终态串。 */
  status?: string;
  /** 原因串。 */
  reason?: string;
  /** 覆盖前留底的备份名。 */
  backupName?: string;
  /** 原始异常。 */
  error?: unknown }

export function createFreshness(cfg: FreshnessCfg) {
  const { cloud, head, safeResolve, busy: _busy = passBusy, hints, lineageFromDurable = true } = cfg;
  // 0.18.0：云端核对没跑成时，干净 ∧ 有 durable etag → 以它为 base（JSDoc 见 FreshnessCfg.lineageFromDurable）。
  //   脏的一律不碰（脏副本的 parent 只能由 recordEdit / 云端确认过的 markSeen 给；从 durable 补 parent 在多标签页下会变成静默覆盖）。
  const adoptDurableBase = (name: string, localDirty?: () => boolean): void => {
    if (!lineageFromDurable) return;
    if (head.isDirtyAnywhere(name) || (localDirty ? localDirty() : false)) return;
    const d = head.seenBase(name);
    if (d != null) head.markSeen(name, d);
  };
  // 0.17.0：刚列过的云端帧里这个文件的 etag === 本 tab 已见 base → 云端没动，和 fetchMeta 得到同样结论，省一趟。
  //   提示说别的（动了 / 没有）一律不采信（可能比我们自己刚推的还旧）。
  const hintedInSync = (name: string): boolean => {
    const h = hints?.peek(name);
    const base = head.seenBase(name);
    return !!h && base != null && h.etag === base;
  };

  // safePull 失败原因 → 用户能懂的短语（喂 reportStoreError；技术 reason 原样兜底）。
  const pullFailText = (reason: string): string =>
    reason === "invalid-cloud-bytes" ? "云端内容没通过校验，可能是公共 Wi-Fi 登录页劫持或文件损坏"
    : reason === "cloud-vanished" ? "云端文件刚刚被移动或删除"
    : reason === "backup-failed" ? "本地留底失败，为保数据没有覆盖"
    : reason;

  async function open(name: string, opts: OpenOpts = {}): Promise<FreshResult> {
    const { isOnline = () => true, probe, onNewer, adopt, localDirty, busy = passBusy, localBytes, localSettled } = opts;
    if (!isOnline()) { adoptDurableBase(name, localDirty); return { source: "local", reason: "offline" }; }
    if (hintedInSync(name)) { head.markSeen(name, head.seenBase(name)!); return { source: "local", reason: "in-sync" }; }   // 同下面 meta.etag===base 分支，只是证据来自刚列的帧
    return busy("cloud.checking", async () => {
      let meta: FetchMetaResult | null;
      if (probe) {
        const raced = await Promise.race([
          cloud.fetchMeta(name).then((m) => ({ k: "meta" as const, m }), (e) => ({ k: "err" as const, e })),
          Promise.resolve(probe).then(() => ({ k: "skip" as const })),
        ]);
        if (raced.k === "skip") { adoptDurableBase(name, localDirty); return { source: "local", reason: "skipped" }; }
        if (raced.k === "err") { adoptDurableBase(name, localDirty); return { source: "local", reason: "cloud-error" }; }
        meta = raced.m;
      } else {
        try { meta = await cloud.fetchMeta(name); } catch (e) { reportStoreError(e, "log"); adoptDurableBase(name, localDirty); return { source: "local", reason: "cloud-error" }; }
      }
      if (!meta) return { source: "local", reason: "cloud-absent" };
      const base = head.seenBase(name);
      if (base != null && meta.etag === base) {
        // 云端 === 本 tab 已见 base（没动）→ in-sync。reload 后内存 _base 空（seenBase 回退共享 etag），
        //   此时 markSeen 重捕 _base（dirty 还顺带重捕 _parent，local-head.ts:82）→ 闭合「dirty 但 _base 空 →
        //   下次推走 no-base fail → 误报 CloudNameCollisionError」窗口。只在 meta.etag===base（云端没动）调=安全：
        //   云端动过会落到下面 dirty→surface 路径，绝不在这里前推 parent（防 B1 silent-overwrite）。
        head.markSeen(name, meta.etag);
        return { source: "local", reason: "in-sync" };
      }
      // !base（无 baseline：从未 synced 的血统 / 谱系丢失）∧ 云端有文件 → 按「云端有别的版本」处理，
      //   对齐 listing.classifySyncState 的 `moved = cloudMoved || !everSynced`（同一事实不许两种结论）。
      //   旧版把 !base 判 in-sync = 静默保留陈旧本地（缺陷 B，20260820-open-time-conflict-surface-handoff）。
      const dirty = head.isDirtyAnywhere(name) || (localDirty ? localDirty() : false);// 全局问题用 isDirtyAnywhere（2026-08-21：别 tab 的未推字节 per-tab 视角看不见）
      if (!dirty) {                                       // clean → 静默快进（无 sheet；safePull 因 clean 跳备份——!base 例外，谱系未知必备份）
        const r = await safeResolve.safePull(name, { adopt });
        // 快进没承诺过什么 → 失败只 info（状态栏，不 banner；captive portal 下每次 open 都会走到这里）。
        if (!r.ok && r.reason !== "edited-during-pull") reportStoreError(new Error(`「${name}」云端有新版本但暂时取不到（${pullFailText(r.reason)}），已打开本地版本`), "info");   // 途中保存导致的作罢不是故障：本地有了未推改动，之后推送自会撞冲突面
        return r.ok ? { source: "fast-forwarded", backupName: r.backupName } : { source: "local", reason: r.reason, error: r.error };
      }
      // 2.2.2：弹面之前先试回执丢失自愈——拉云端逐字节比，一样就认领（同 push 的 tryHeal）。慢网：probe（「跳过到离线」）先到 → 当 skipped（不弹面、谱系不动；
      //   迟到的比对若相等仍会 markSynced，那是关于字节的事实、无害）。拉失败 = 比不出，照旧交 ui。
      //   先用 meta 里的大小当闸（零网络）：大小不同 = 不可能一样 → 不拉、直接弹面（守住「面前不预拉整份云端」——QA 2026-08-20 / store-open-conflict 测试）；大小一样才拉来逐字节比。
      if (localBytes && safeResolve.tryHeal) {
        const mine = await localBytes().catch((e) => { reportStoreError(e, "log"); return null; });
        if (mine && (meta.size == null || meta.size === mine.byteLength)) {
          const healing = (async () => { try { return await safeResolve.tryHeal!(name, mine, { settled: localSettled }); } catch (e) { reportStoreError(e, "log"); return false; } })();
          const outcome = probe ? await Promise.race([healing.then((h) => ({ k: "heal" as const, h })), Promise.resolve(probe).then(() => ({ k: "skip" as const }))]) : { k: "heal" as const, h: await healing };
          if (outcome.k === "skip") return { source: "local", reason: "skipped" };
          if (outcome.h) return { source: "local", reason: "healed" };
        }
      }
      // dirty 分叉 → 交 ui（takeCloud=拉 / keepMine|cancel=留本地）
      const choice = onNewer ? await onNewer({ name, cloudEtag: meta.etag, baseEtag: base, cloudTime: meta.lastModified }) : "cancel";
      if (choice === "takeCloud") {
        // forceBackup：这里本来就是 dirty（必备份），加它不改变备份行为；它表达的是「用户明确选了换世界线」——
        //   下载途中又保存过时，safePull 据此把那一份再备份一次然后照用户的意思覆盖，而不是作罢（0.15.2）。
        const r = await safeResolve.safePull(name, { adopt, forceBackup: true });
        // 用户显式选了「用云端」却没成 → warning（banner）：绝不让用户以为打开的是云端版（反煤气灯）。
        if (!r.ok) reportStoreError(new Error(`「${name}」未能取回云端版本（${pullFailText(r.reason)}），本次打开的仍是本地版本`), "warning");
        return r.ok ? { source: "pulled", backupName: r.backupName } : { source: "local", reason: r.reason, backupName: r.backupName, error: r.error };
      }
      return { source: "local", reason: "kept" };
    });
  }

  // 事件驱动干净快进：dirty → no-op（绝不在事件里弹 sheet；后续 push 的 412 会 surface 真分叉）。
  async function refresh(name: string, opts: RefreshOpts = {}): Promise<FreshResult> {
    const { isOnline = () => true, adopt, localDirty, onReplaceStart, probe, busy = passBusy, trustHints = true } = opts;
    if (!isOnline()) return { status: "offline" };
    if (head.isDirtyAnywhere(name) || (localDirty && localDirty())) return { status: "dirty-skip" };   // anywhere：快进覆盖的是**共享**本地字节，别 tab 的未推编辑也要挡
    if (trustHints && hintedInSync(name)) { head.markSeen(name, head.seenBase(name)!); return { status: "in-sync" }; }   // 0.18.1：trustHints:false = 醒来 / 回前台这种时刻一定问云端
    return busy("cloud.checking", async () => {
      let meta: FetchMetaResult | null;
      try { meta = await cloud.fetchMeta(name); } catch (e) { reportStoreError(e, "log"); return { status: "cloud-error" }; }
      if (!meta) return { status: "cloud-absent" };
      const base = head.seenBase(name);
      // !base ∧ 云端有 → 同 open：按 moved 处理（对齐 listing；clean-only 路径 → 直接快进采纳云端）。
      if (base != null && meta.etag === base) {
        // 0.16.2（2026-10-08，MoonSinger「写着写着过一会就跳一次冲突面」案）：in-sync 也要 markSeen 重捕 _base——和 open 的同一分支对称。
        //   reload 后内存 _base 空；宿主要是在登录**之前**就开了文档（MoonSinger / WXHW 的 boot 顺序：建 store → 本地恢复 → initAuth），
        //   open 的 gate 因云端不可达跳过、没重捕；登录后走的是这里（pullIfClean）——以前直接 return，_base 永远空 →
        //   本 tab 第一次编辑 recordEdit 捕到 parent=null → 推不带 If-Match → conflictBehavior:"fail" → 409 → 误报
        //   CloudNameCollisionError 冲突面（每次 reload 一次；人选「本地覆盖云端」markSynced 之后才好）。
        //   安全性同 open 那一行：云端 === 本 tab 已见 base（没动）才调；且进到这里之前 isDirtyAnywhere 已经挡过——只给干净 tab 重捕，
        //   绝不在云端动过时前推 parent（B1 silent-overwrite 守住）。
        head.markSeen(name, meta.etag);
        return { status: "in-sync" };
      }
      if (head.isDirtyAnywhere(name) || (localDirty && localDirty())) return { status: "dirty-skip" };   // anywhere：快进覆盖的是**共享**本地字节，别 tab 的未推编辑也要挡  // fetchMeta 期间用户动了笔 → 放弃
      if (onReplaceStart) onReplaceStart();
      // 逃生 race（2026-08-25）：probe 先到 → "escaped"（分叉 consent）。safePull 继续在后台跑完 = 原名
      //   缓存静默刷新（这里没传 adopt 时画布不碰；错误 funnel 到 log，不打扰已走人的用户）。
      const pulling = safeResolve.safePull(name, { adopt });
      if (probe) {
        const winner = await Promise.race([pulling.then((r) => ({ r })), Promise.resolve(probe).then(() => null)]);
        if (winner == null) { pulling.catch((e) => reportStoreError(e, "log")); return { status: "escaped" }; }
        return winner.r.ok ? { status: "fast-forwarded" } : winner.r.reason === "edited-during-pull" ? { status: "dirty-skip" } : { status: "ff-failed", reason: winner.r.reason };
      }
      const r = await pulling;
      if (!r.ok && r.reason === "edited-during-pull") return { status: "dirty-skip" };   // 0.15.2：下载途中本地有了改动 → 这次快进作罢（同「本来就脏」）
      return r.ok ? { status: "fast-forwarded" } : { status: "ff-failed", reason: r.reason };
    });
  }

  return { open, refresh };
}
